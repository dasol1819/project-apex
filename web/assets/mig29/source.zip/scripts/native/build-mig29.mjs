// Checksum-pinned native table extension; all legacy rows and state addresses stay intact.
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import wabtFactory from "wabt";
process.on("uncaughtException", (e) => {
  console.error(e.message);
  process.exit(1);
});
const root = path.resolve(
    path.dirname(fileURLToPath(import.meta.url)),
    "../..",
  ),
  build = path.join(root, ".native-build");
execFileSync(
  process.execPath,
  [path.join(root, "scripts/native/build-su35.mjs")],
  { stdio: "inherit" },
);
const baseline = fs.readFileSync(path.join(root, "web/flight.wasm"));
fs.writeFileSync(path.join(build, "su35-baseline.wasm"), baseline);
const s = new WebAssembly.Instance(new WebAssembly.Module(baseline), {
    env: {
      pow: Math.pow,
      atan2: Math.atan2,
      asin: Math.asin,
      external_terrain: () => 0,
    },
  }).exports,
  memory = Buffer.from(s.memory.buffer),
  layout = JSON.parse(fs.readFileSync(path.join(build, "layout.json"))),
  old = layout.regions,
  config = JSON.parse(
    fs.readFileSync(path.join(root, "assets/mig29-combat/config.json")),
  ),
  shapes = JSON.parse(
    fs.readFileSync(path.join(root, "assets/mig29-combat/shapes.json")),
  );
let wat = fs.readFileSync(path.join(build, "su35.wat"), "utf8"),
  cursor = memory.length;
const regions = {},
  data = [];
const expect = (a, m) => {
  if (!a) throw Error(m);
};
function region(name, b) {
  cursor = Math.ceil(cursor / 16) * 16;
  const at = cursor;
  cursor += b.length;
  regions[name] = at;
  data.push({ at, b });
  return at;
}
function change(name, fn) {
  const start = wat.indexOf("  (func $" + name + " ");
  expect(start >= 0, "Missing function " + name);
  const end = wat.indexOf("\n  (", start + 1),
    before = wat.slice(start, end),
    after = fn(before);
  expect(after !== before, "No patch " + name);
  wat = wat.slice(0, start) + after + wat.slice(end);
}
function pre(name, code) {
  change(name, (b) => {
    let at = b.indexOf("\n") + 1;
    if (b.slice(at).startsWith("    (local")) at = b.indexOf("\n", at) + 1;
    return b.slice(0, at) + code + "\n" + b.slice(at);
  });
}
const current = "i32.const 0\n    i32.load offset=1119524",
  isMig = current + "\n    i32.const 14\n    i32.eq";
const relocated = [];
function table(name, count, stride, fill) {
  const b = Buffer.alloc(count * stride);
  memory.copy(b, 0, old[name], old[name] + (count - 1) * stride);
  fill(b);
  const at = region(name, b);
  relocated.push([old[name], stride, at]);
  return at;
}
const frames = table("airframes", 15, 288, (b) => {
  memory.copy(b, 14 * 288, old.airframes + 13 * 288, old.airframes + 14 * 288);
  for (const [o, v] of Object.entries(config.airframeDoubles))
    b.writeDoubleLE(v, 14 * 288 + Number(o));
  for (const [o, v] of Object.entries(config.airframeInts))
    b.writeInt32LE(v, 14 * 288 + Number(o));
});
table("rcs", 15, 8, (b) => b.writeDoubleLE(config.rcs, 14 * 8));
table("radars", 15, 56, (b) => {
  [config.radar.range, 0, 2.7, (12 * Math.PI) / 180, 30, 0.56].forEach((v, i) =>
    b.writeDoubleLE(v, 14 * 56 + i * 8),
  );
  b.writeInt32LE(0, 14 * 56 + 48);
  b.writeInt32LE(1, 14 * 56 + 52);
});
const profiles = Buffer.alloc(45 * 24);
memory.copy(profiles, 0, old.loadouts, old.loadouts + 42 * 24);
for (const p of config.loadouts)
  [14, p.ir, p.rfMask, -1, 0, 0].forEach((v, i) =>
    profiles.writeInt32LE(v, p.id * 24 + i * 4),
  );
const presetAt = region("loadouts", profiles);
relocated.push([old.loadouts, 24, presetAt]);
table("irAttachmentParts", 15, 4, (b) => b.writeInt32LE(12, 14 * 4));
wat = wat.replace(/\bi32\.const (\d+)\b/g, (token, n) => {
  const v = Number(n),
    r = relocated.find(([a, size]) => v >= a && v < a + size);
  return r ? "i32.const " + (r[2] + v - r[0]) : token;
});
let guards = 0;
wat = wat.replace(/i32\.const 14\n(\s+)i32\.lt_u/g, (_, sp) => {
  guards++;
  return "i32.const 15\n" + sp + "i32.lt_u";
});
expect(guards === 28, "Expected 28 aircraft bounds");
const bits = (1n << 42n) | (1n << 43n) | (1n << 44n);
for (const oldMask of [219916330153n, 219949884585n, 256489944831n]) {
  const token =
    "i64.const " + (oldMask | (1n << 38n) | (1n << 40n) | (1n << 41n)) + "\n";
  expect(wat.includes(token), "Profile capability mask");
  wat = wat.replaceAll(
    token,
    "i64.const " +
      (oldMask | (1n << 38n) | (1n << 40n) | (1n << 41n) | bits) +
      "\n",
  );
}
for (const n of ["Loadouts::ensure__", "set_strike_loadout"])
  change(n, (b) => b.replaceAll("i32.const 42\n", "i32.const 45\n"));
change("set_loadout", (b) => b.replace("i32.const 41\n", "i32.const 44\n"));
pre(
  "Airframes::partPresent_int__int_",
  `    local.get 1\n    i32.const 14\n    i32.eq\n    local.get 1\n    i32.const 0\n    i32.lt_s\n    ${isMig}\n    i32.and\n    i32.or\n    if\n      local.get 0\n      i32.const 30\n      i32.lt_u\n      return\n    end`,
);
function vectors(name, rows) {
  const b = Buffer.alloc(rows.length * 24);
  rows.flat().forEach((v, i) => b.writeDoubleLE(v, i * 8));
  return region(name, b);
}
function copy(at) {
  return [0, 8, 16]
    .map(
      (o) =>
        `      local.get 0\n      local.get 1\n      i32.const 24\n      i32.mul\n      i32.const ${at + o}\n      i32.add\n      f64.load\n      f64.store offset=${o}`,
    )
    .join("\n");
}
for (const [name, key] of [
  ["shapePivot_int__int__double_", "pivot"],
  ["shapeHalf_int__int__double_", "half"],
]) {
  const at = vectors(
    key,
    shapes.parts.map((p) => p[key]),
  );
  pre(
    name,
    `    local.get 2\n    i32.const 14\n    i32.eq\n    local.get 2\n    i32.const 0\n    i32.lt_s\n    ${isMig}\n    i32.and\n    i32.or\n    if\n${copy(at)}\n      return\n    end`,
  );
}
const gearAt = vectors("gearContacts", shapes.gearContacts);
pre(
  "shapeProbe_int__V_",
  `    ${isMig}\n    local.get 1\n    i32.const 24\n    i32.sub\n    i32.const 3\n    i32.lt_u\n    i32.and\n    if\n${[0, 8, 16].map((o) => `      local.get 0\n      local.get 1\n      i32.const 24\n      i32.sub\n      i32.const 24\n      i32.mul\n      i32.const ${gearAt + o}\n      i32.add\n      f64.load\n      f64.store offset=${o}`).join("\n")}\n      return\n    end`,
);
for (const [name, rows] of [
  ["Airframes::irMount_int_", config.irMounts],
  ["Airframes::rfMount_int_", config.rfMounts],
]) {
  const at = vectors(name, rows);
  pre(name, `    ${isMig}\n    if\n${copy(at)}\n      return\n    end`);
}
pre(
  "Combat::storeMass__",
  `    ${isMig}\n    if\n      f64.const 0\n${[...Array.from({ length: 4 }, (_, i) => [1079208 + i, 105]), ...Array.from({ length: 2 }, (_, i) => [1079232 + i, 253])].map(([a, m]) => `      i32.const 0\n      i32.load8_u offset=${a}\n      ${a < 1079232 ? "i32.const 0\n      i32.load8_u offset=" + (1079212 + a - 1079208) + "\n      i32.and\n      " : ""}f64.convert_i32_u\n      f64.const ${m}\n      f64.mul\n      f64.add`).join("\n")}\n      return\n    end`,
);
pre(
  "Amraam::attached_int_",
  `    ${isMig}\n    if\n      local.get 0\n      i32.const 2\n      i32.lt_u\n      i32.const 0\n      i32.load offset=1119916\n      i32.const 24\n      i32.mul\n      i32.const ${presetAt + 8}\n      i32.add\n      i32.load\n      local.get 0\n      i32.shr_u\n      i32.const 1\n      i32.and\n      i32.and\n      local.get 0\n      i32.const 1\n      i32.and\n      i32.const 1\n      i32.add\n      i32.const 8\n      i32.mul\n      i32.const 1133512\n      i32.add\n      f64.load\n      f64.const 0.08\n      f64.ge\n      i32.and\n      return\n    end`,
);
// Conventional MiG-29 flaps are separate from its ailerons, with no rudder
// toe-out airbrake mixing. Keep native actuator health, rate and lag handling.
pre(
  "DamageState::move_int__double__double__double__double__double__const",
  `    ${isMig}\n    local.get 1\n    i32.const 16\n    i32.sub\n    i32.const 2\n    i32.lt_u\n    i32.and\n    if\n      i32.const 0\n      f64.load offset=1109680\n      f64.const ${(25 * Math.PI) / 180}\n      f64.mul\n      local.set 3\n      f64.const 0.22\n      local.set 4\n      f64.const 0.18\n      local.set 5\n    end`,
);
change(
  "coefficients_double__double__double__double__double__double__double__double__double__double__double_",
  (body) => {
    const terms = [
      ...Array.from({ length: 4 }, (_, i) => [1079208 + i, 0.0005]),
      ...Array.from({ length: 2 }, (_, i) => [1079232 + i, 0.00055]),
    ]
      .map(
        ([a, c]) =>
          `      i32.const 0\n      i32.load8_u offset=${a}\n      f64.convert_i32_u\n      f64.const ${c}\n      f64.mul\n      f64.add`,
      )
      .join("\n");
    const end = body.lastIndexOf(")");
    return (
      body.slice(0, end) +
      `    ${isMig}\n    if\n      local.get 0\n      local.get 0\n      f64.load offset=8\n${terms}\n      f64.const 0.0009\n      f64.add\n      f64.store offset=8\n    end\n` +
      body.slice(end)
    );
  },
);
// The N019 table has no TWS. Clamp explicit mode changes to RWS; STT
// acquisition remains controlled by the native lock command.
pre(
  "set_radar_mode",
  `    ${isMig}\n    if\n      i32.const 1\n      local.set 0\n    end`,
);
change("set_aircraft_type", (body) => {
  const end = body.lastIndexOf(")");
  return (
    body.slice(0, end) +
    `    ${isMig}\n    if\n      i32.const 0\n      i32.const 1\n      i32.store offset=1079168\n      i32.const 0\n      i32.const 1\n      i32.store offset=1079172\n    end\n` +
    body.slice(end)
  );
});
for (const name of [
  "Awareness::choose_int__State_const&_",
  "ObjectSensors::choose_int_",
  "set_combat_ai",
  "step",
])
  change(name, (body) =>
    body.replace(
      /i32\.const -3\n(\s+)i32\.add\n\s+i32\.const -2\n\s+i32\.lt_u/g,
      (m, sp) => m + `\n${sp}${isMig}\n${sp}i32.eqz\n${sp}i32.and`,
    ),
  );
const sarh = (b) =>
  b.replace(
    /i32\.const 0\n(\s+)i32\.load offset=1119524/g,
    (_, sp) => `i32.const 1\n${sp}${current}\n${sp}${isMig}\n${sp}select`,
  );
change("Amraam::request_bool_", sarh);
change("get_amraam_state", (b) => {
  const needle = "    i32.const 1397024)";
  expect(b.includes(needle), "RF output");
  return b.replace(
    needle,
    `    ${isMig}\n    if\n      i32.const 1397248\n      f64.const 27\n      f64.store\n    end\n` +
      needle,
  );
});
change("step", (body) => {
  // R-73 shares the dedicated short-range native profile, not AIM-9 defaults.
  const irStart = body.search(/i32\.const 28\n\s+i32\.const 45\n/),
    irEnd = body.indexOf(
      "        local.get 1\n        i32.const 3600",
      irStart,
    );
  expect(irStart > 0 && irEnd > irStart, "R-73 profile boundary");
  let ir = body.slice(irStart, irEnd);
  ir = ir.replace(
    /i32\.const 13\n(\s+)i32\.eq/g,
    (m, sp) => m + `\n${sp}${isMig}\n${sp}i32.or`,
  );
  body = body.slice(0, irStart) + ir + body.slice(irEnd);
  const controlStart = body.indexOf("f64.store offset=1109968"),
    controlEnd = body.indexOf("f64.store offset=1109984", controlStart);
  expect(
    controlStart > 0 && controlEnd > controlStart,
    "MiG aileron control block",
  );
  let controls = body.slice(controlStart, controlEnd);
  for (const n of [42, 49]) {
    const token = "local.tee " + n;
    expect(controls.includes(token), "Aileron common mix " + n);
    controls = controls.replace(
      token,
      `local.set ${n}\n    ${isMig}\n    if\n      f64.const 0\n      local.set ${n}\n    end\n    local.get ${n}`,
    );
  }
  body = body.slice(0, controlStart) + controls + body.slice(controlEnd);
  const rudderStart = body.indexOf("f64.store offset=1109984"),
    rudderEnd = body.indexOf("f64.store offset=1110000", rudderStart);
  let rudder = body.slice(rudderStart, rudderEnd);
  const toe = "local.tee 19";
  expect(rudder.includes(toe), "Rudder toe-out mix");
  rudder = rudder.replace(
    toe,
    `local.set 19\n    ${isMig}\n    if\n      f64.const 0\n      local.set 19\n    end\n    local.get 19`,
  );
  body = body.slice(0, rudderStart) + rudder + body.slice(rudderEnd);
  const rfStart = body.indexOf("i32.store offset=1350844"),
    rfEnd = body.indexOf("call 223", rfStart);
  expect(rfStart > 0 && rfEnd > rfStart, "RF solver boundary");
  let rf = sarh(body.slice(rfStart, rfEnd));
  const motion =
    "        local.get 1\n        local.get 0\n        f64.store offset=3712\n        local.get 1\n        local.get 12\n        f64.store offset=3704";
  expect(rf.includes(motion), "RF motion parameters");
  rf = rf.replace(
    motion,
    `        ${isMig}\n        if\n          f64.const 35\n          local.set 23\n          f64.const 2\n          local.set 18\n          f64.const 5\n          local.set 16\n          f64.const 220\n          local.set 19\n          f64.const 1400\n          local.set 12\n          f64.const 30\n          local.set 0\n        end\n` +
      motion,
  );
  body = body.slice(0, rfStart) + rf + body.slice(rfEnd);
  for (const [local, anchor] of [
    [4, "i32.const 860"],
    [3, "f64.const 0x1.0cccccccccccdp+1"],
  ]) {
    const at = body.indexOf(anchor, body.indexOf("i32.const 860")),
      tail = body.slice(at);
    const re = new RegExp(
      `local\\.get ${local}\\n(\\s+)i32\\.const 10\\n\\s+i32\\.eq`,
    );
    body =
      body.slice(0, at) +
      tail.replace(re, (m, sp) => m + `\n${sp}${isMig}\n${sp}i32.or`);
  }
  const lookup = body.indexOf("i32.const " + regions.irAttachmentParts);
  expect(lookup > 0, "IR damage guard");
  body =
    body.slice(0, lookup) +
    body
      .slice(lookup)
      .replace(
        /i32\.const 13\n(\s+)i32\.gt_u/,
        (_, sp) => "i32.const 14\n" + sp + "i32.gt_u",
      );
  const gun = body.indexOf("i32.const 6160"),
    health = body.indexOf("i32.const 1133512", gun),
    at = body.lastIndexOf("      local.get 3", health);
  expect(at > gun, "Gun damage body");
  body =
    body.slice(0, at) +
    `      ${isMig}\n      if\n        i32.const 0\n        local.set 3\n      end\n` +
    body.slice(at);
  return body;
});
const pages = Math.ceil(cursor / 65536);
wat = wat.replace("(memory (;0;) 221)", "(memory (;0;) " + pages + ")");
wat =
  wat.slice(0, wat.lastIndexOf(")")) +
  data
    .map(
      ({ at, b }) =>
        "  (data (i32.const " +
        at +
        ') "' +
        [...b].map((v) => "\\" + v.toString(16).padStart(2, "0")).join("") +
        '")',
    )
    .join("\n") +
  "\n)";
fs.writeFileSync(path.join(build, "mig29.wat"), wat);
const wabt = await wabtFactory(),
  p = wabt.parseWat("mig29.wat", wat, {
    bulk_memory: true,
    nontrapping_fptoint: true,
  });
p.resolveNames();
p.validate();
const { buffer } = p.toBinary({ write_debug_names: true });
fs.writeFileSync(path.join(root, "web/flight.wasm"), Buffer.from(buffer));
fs.writeFileSync(
  path.join(build, "mig29-layout.json"),
  JSON.stringify({ regions, guards, pages }, null, 2),
);
console.log(
  JSON.stringify({ result: "BUILT", bytes: buffer.length, guards, pages }),
);
