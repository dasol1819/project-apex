// Every world-space ShaderMaterial must share the standard material depth convention.
export function enableWorldDepth(material){
 if(!material?.isShaderMaterial||material.userData.worldDepth)return material;
 const vertex=material.vertexShader,last=vertex.lastIndexOf('}');
 material.vertexShader='#include <common>\n#include <logdepthbuf_pars_vertex>\n'+vertex.slice(0,last)+'\n#include <logdepthbuf_vertex>\n'+vertex.slice(last);
 material.fragmentShader='#include <logdepthbuf_pars_fragment>\n'+material.fragmentShader.replace(/void\s+main\s*\(\s*\)\s*\{/,match=>match+'\n#include <logdepthbuf_fragment>\n');
 material.userData.worldDepth=true;material.needsUpdate=true;return material;
}
export function enableWorldDepthIn(root){root.traverse(node=>{for(const material of Array.isArray(node.material)?node.material:[node.material])enableWorldDepth(material);});}
