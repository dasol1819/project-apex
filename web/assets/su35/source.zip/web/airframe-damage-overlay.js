import * as T from './vendor/three.module.js';

// Independent diagnostic shells follow each real component and hinge. They are
// never part of the physical airframe and cannot be captured in debris meshes.
// Detached or destroyed components have no diagnostic surface left to draw.
export function createAirframeDamageOverlay(aircraftRoot, parts) {
  const root = new T.Group(); root.name = 'component damage inspection'; root.visible = false; root.userData.damageOverlay = true;
  const entries = parts.map((source, index) => {
    const material = new T.MeshBasicMaterial({color:0xff2718,transparent:true,opacity:0,depthWrite:false,depthTest:true,side:T.FrontSide,polygonOffset:true,polygonOffsetFactor:-3,polygonOffsetUnits:-3,toneMapped:false});
    material.name = `damage severity ${index}`;
    const transforms = [];
    function clone(node, isRoot = false) {
      if (node.isLine || node.isLineSegments || node.userData.fractureFace || node.userData.damageOverlay) return null;
      if (node.isMesh && (Array.isArray(node.material) || node.material.isShaderMaterial)) return null;
      const copy = node.isMesh ? new T.Mesh(node.geometry, material) : new T.Group();
      copy.name = `damage overlay / ${node.name}`; copy.userData.damageOverlay = true; copy.userData.damageIndex = index;
      copy.matrixAutoUpdate = false; copy.renderOrder = 7; copy.castShadow = copy.receiveShadow = false;
      transforms.push({source:node,copy,isRoot});
      for (const child of node.children) { const c = clone(child); if (c) copy.add(c); }
      return copy;
    }
    const copy = clone(source, true); root.add(copy);
    return {source,root:copy,material,transforms};
  });
  aircraftRoot.add(root);
  let currentHealth = Array(parts.length).fill(1);
  function update(health = currentHealth) {
    currentHealth = health;
    if (!root.visible) return;
    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i], integrity = Number.isFinite(health[i]) ? Math.max(0,Math.min(1,health[i])) : 1;
      entry.root.visible = integrity >= .08 && integrity < .999 && entry.source.visible;
      entry.root.userData.missing = integrity < .08;
      entry.material.opacity = integrity < .08 ? 0 : .045 + .40 * Math.pow(1 - integrity, .80);
      if (!entry.root.visible) continue;
      for (const pair of entry.transforms) {
        pair.source.updateMatrix(); pair.copy.matrix.copy(pair.source.matrix); pair.copy.matrixWorldNeedsUpdate = true;
        if (!pair.isRoot) pair.copy.visible = pair.source.visible;
      }
    }
  }
  return { root, entries, update, setEnabled(enabled) { root.visible = !!enabled; update(); return root.visible; } };
}
