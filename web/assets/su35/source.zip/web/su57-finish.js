import * as T from './vendor/three.module.js';

// Authored in aircraft metres, following the connected, smaller-aircraft
// silhouette visible in Su-57 exterior photographs. Pixel detail breaks its
// boundary; it does not replace the silhouette with unrelated rectangles.
export const SU57_PALETTE=[0xb9c3ca,0x526776,0x879ba9,0xbccbd4];
const rgb=hex=>'vec3('+new T.Color(hex).toArray().map(v=>v.toFixed(5)).join(',')+')';
export const su57FinishGLSL=`
 float felonSpine(vec2 p){
  float z=p.y;
  float width=mix(.34,.80,smoothstep(-6.55,-4.85,z));
  width=mix(width,2.15,smoothstep(-4.85,-.75,z));
  width=mix(width,1.76,smoothstep(1.10,3.55,z));
  width=mix(width,.36,smoothstep(3.55,6.65,z));
  return step(abs(p.x),width)*step(-6.65,z)*(1.-step(7.85,z));
 }
 float felonSilhouette(vec2 p){
  vec2 q=vec2(abs(p.x),p.y);
  float body=felonSpine(p);
  float wing=coatField(q,vec2(1.30,-3.15),vec2(6.78,2.68),vec2(6.26,3.28),vec2(1.26,2.18),.006);
  float shoulder=coatField(q,vec2(1.13,-3.68),vec2(2.25,-2.10),vec2(3.75,.22),vec2(1.48,.85),.006);
  float tail=coatField(q,vec2(.38,4.36),vec2(2.22,5.48),vec2(4.52,8.55),vec2(1.16,7.85),.006);
  return max(max(body,wing),max(shoulder,tail));
 }
 float felonDigital(vec2 p){
  vec2 cell=vec2(.135,.155),id=floor(p/cell),q=(id+.5)*cell;
  // Rows share short blocks, giving the stepped fingers and isolated pixels
  // of the painted edge rather than the previous regular stair-step diagonal.
  q.x+=(floor(coatHash(vec3(floor(id.y/3.),4.,1.))*5.)-2.)*cell.x;
  q.y+=(floor(coatHash(vec3(floor(id.x/3.),7.,2.))*3.)-1.)*cell.y;
  float main=felonSilhouette(q),edge=abs(felonSilhouette(q+vec2(.30,.15))-felonSilhouette(q-vec2(.30,.15)));
  float islands=step(.83,coatHash(vec3(floor(id/2.),6.)))*edge;
  return mix(main,1.-main,islands*.93);
 }
 float felonPanels(vec3 p){
  vec2 q=vec2(abs(p.x),p.z);float d=10.;
  if(classicPart==0.||classicPart==29.){
   d=min(abs(coatBox(p.xz-vec2(0.,-1.30),vec2(.48,1.45))),abs(coatBox(p.xz-vec2(0.,2.10),vec2(.40,1.10))));
   d=min(d,coatSegment(q,vec2(.76,-3.05),vec2(.93,3.65)));
   d=min(d,coatSegment(q,vec2(.32,-3.00),vec2(1.65,-2.65)));
   d=min(d,coatSegment(q,vec2(.38,.65),vec2(1.70,.86)));
   d=min(d,coatSegment(q,vec2(.46,3.80),vec2(1.45,3.97)));
  }else if(classicPart==7.||classicPart==8.){
   float a=atan(p.y+.30,abs(p.x)-1.62);
   d=min(abs(fract((p.z-3.80)/.74+.5)-.5)*.74,abs(fract(a*3.1831+.5)-.5)*.20);
  }else if(classicPart==5.||classicPart==6.||classicPart==20.||classicPart==21.){
   d=min(coatSegment(p.zy,vec2(5.10,.80),vec2(7.65,1.04)),coatSegment(p.zy,vec2(6.08,1.96),vec2(7.94,2.10)));
  }else if(classicPart==1.||classicPart==2.||classicPart>=12.&&classicPart<=19.){
   float le=-3.90+(q.x-1.80)*1.124,te=4.90-(q.x-1.80)*.248;
   d=min(abs(p.z-mix(le,te,.10)),abs(p.z-mix(le,te,.77)));
   d=min(d,coatSegment(q,vec2(2.80,-2.82),vec2(2.80,4.58)));
   d=min(d,coatSegment(q,vec2(4.20,-1.20),vec2(4.20,4.30)));
   d=min(d,coatSegment(q,vec2(5.74,.57),vec2(5.74,3.90)));
  }else if(classicPart==3.||classicPart==4.){
   d=min(coatSegment(q,vec2(2.14,6.60),vec2(4.72,8.63)),coatSegment(q,vec2(2.30,6.00),vec2(2.30,9.20)));
  }
  return d;
 }
`;

export const su57PaintField=`
 float digital=felonDigital(p.xz);
 vec3 coat=mix(${rgb(SU57_PALETTE[0])},${rgb(SU57_PALETTE[1])},digital);
 float middle=felonSpine(p.xz)*(1.-digital)*.35;
 coat=mix(coat,${rgb(SU57_PALETTE[2])},middle);
 if(classicPart==5.||classicPart==6.||classicPart==20.||classicPart==21.){
  vec2 f=floor(p.zy/vec2(.14,.14))*vec2(.14,.14);
  float band=coatField(f,vec2(4.9,.7),vec2(6.65,1.00),vec2(7.86,2.10),vec2(6.38,2.37),.006);
  float notch=step(.79,coatHash(vec3(floor(f/.28),9.)))*step(.65,p.y)*step(p.y,2.3);
  coat=mix(${rgb(SU57_PALETTE[0])},${rgb(SU57_PALETTE[1])},abs(band-notch));
 }
`;

export const su57MetalFinish=`
 float axial=clamp((p.z-3.72)/4.5,0.,1.);
 float ring=1.-smoothstep(.012,.034,abs(fract((p.z-3.85)*1.35+.5)-.5));
 float angle=atan(p.y+.30,abs(p.x)-1.62);
 float flutes=.5+.5*cos(angle*24.);
 vec3 tint=mix(vec3(.93,.97,1.03),vec3(.56,.61,.66),axial);
 tint=mix(tint,vec3(.76,.67,.55),smoothstep(.32,.72,axial)*.34);
 tint=mix(tint,vec3(.55,.65,.76),(1.-smoothstep(.06,.25,abs(axial-.42)))*.28);
 diffuseColor.rgb*=tint*(.94+grain*.055-ring*.13+flutes*.018);
`;
