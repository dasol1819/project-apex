import * as T from './vendor/three.module.js';
import {WEAPONS} from './loadout-catalog.js';
// Original meshes using approximate public overall dimensions, nose points -Z.
export const BOMB_MOUNTS=Object.freeze([Object.freeze([-.54,-1.55,.30]),Object.freeze([.54,-1.55,.30])]);
export function createBombModel(id=0,{deployed=false}={}){
 const w=WEAPONS[id]||WEAPONS[0],root=new T.Group(),r=w.diameter/2,L=w.length;
 root.name=w.name;root.userData={weaponId:w.id,mass:w.mass,deployed};
 const paint=new T.MeshStandardMaterial({color:id===6?0xc0c6bf:id===5?0xb4b2a3:0x555e42,roughness:.69,metalness:.19}),metal=new T.MeshStandardMaterial({color:0x8e9795,roughness:.47,metalness:.58}),band=new T.MeshStandardMaterial({color:0xd7b44f,roughness:.6}),glass=new T.MeshStandardMaterial({color:0x193d46,roughness:.15,metalness:.5});
 const add=(geo,mat=paint,p=[0,0,0])=>{const m=new T.Mesh(geo,mat);m.position.set(...p);m.castShadow=m.receiveShadow=true;root.add(m);return m;};
 const points=[[0,-L*.5],[r*.48,-L*.465],[r*.86,-L*.37],[r,-L*.26],[r,L*.22],[r*.72,L*.36],[r*.42,L*.46],[r*.42,L*.5]].map(([x,y])=>new T.Vector2(x,y));
 const body=new T.LatheGeometry(points,24);body.rotateX(Math.PI/2);add(body);
 const stripe=new T.CylinderGeometry(r*1.005,r*1.005,.045,24);stripe.rotateX(Math.PI/2);add(stripe,band,[0,0,-L*.22]);
 const fin=(z,span,chord,mat=paint)=>{for(let i=0;i<4;i++){const g=new T.BufferGeometry(),a=r*.55,b=span/2;g.setAttribute('position',new T.Float32BufferAttribute([a,0,z-chord/2,b,0,z+chord*.1,b,0,z+chord/2,a,0,z+chord/2],3));g.setIndex([0,1,2,0,2,3]);g.computeVertexNormals();const m=add(g,mat);m.material.side=T.DoubleSide;m.rotation.z=Math.PI/4+i*Math.PI/2;}};
 fin(L*.37,w.diameter*(id===1?2.1:1.8),L*.19);
 if(id===1||id===6){fin(-L*.28,w.diameter*1.7,L*.12,metal);const seeker=new T.SphereGeometry(r*.52,20,12);seeker.scale(1,1,.65);add(seeker,glass,[0,0,-L*.49]);}
 if(id>=2&&id<=4){for(let i=0;i<4;i++){const m=add(new T.BoxGeometry(.018,r*.42,L*.44),metal,[0,0,0]);m.position.set(Math.cos(i*Math.PI/2)*r,Math.sin(i*Math.PI/2)*r,0);m.rotation.z=i*Math.PI/2-Math.PI/2;}}
 if(id===5){const wing=add(new T.BoxGeometry(deployed?1.52:.20,.035,.33),metal,[0,.12,.05]);wing.name=deployed?'deployed SDB glide wings':'folded SDB glide wings';add(new T.BoxGeometry(.10,.055,L*.65),metal,[0,.12,0]);}
 return root;
}
export function setBombModel(holder,id,options={}){if(holder.userData.weaponId===id&&holder.userData.deployed===!!options.deployed)return;for(const child of [...holder.children]){holder.remove(child);child.traverse(o=>{o.geometry?.dispose();for(const m of Array.isArray(o.material)?o.material:[o.material])m?.dispose();});}holder.add(createBombModel(id,options));holder.userData.weaponId=id;holder.userData.deployed=!!options.deployed;}
export function createTargetingPod(variant='generic'){if(variant==='atflir')return createATFLIR();const root=new T.Group();root.name='targeting pod / optical gimbal';const paint=new T.MeshStandardMaterial({color:0x737c80,roughness:.62,metalness:.25}),glass=new T.MeshStandardMaterial({color:0x173e4d,roughness:.12,metalness:.6});const body=new T.Mesh(new T.CylinderGeometry(.16,.18,2.2,24),paint);body.rotation.x=Math.PI/2;root.add(body);const head=new T.Mesh(new T.SphereGeometry(.19,24,16),paint);head.position.z=-1.07;root.add(head);const lens=new T.Mesh(new T.CircleGeometry(.115,24),glass);lens.rotation.y=Math.PI;lens.position.set(0,-.04,-1.245);root.add(lens);const pylon=new T.Mesh(new T.BoxGeometry(.10,.28,.85),paint);pylon.position.y=.28;root.add(pylon);return root;}

// Authored exterior of the short cheek-mounted ATFLIR pod; no sensor internals.
function createATFLIR(){
 const root=new T.Group();root.name='AN/ASQ-228 ATFLIR / authored exterior';
 const shell=new T.MeshStandardMaterial({color:0x7b878d,roughness:.66,metalness:.24}),glass=new T.MeshStandardMaterial({color:0x163c45,roughness:.15,metalness:.52}),dark=new T.MeshStandardMaterial({color:0x30393e,roughness:.74});
 const body=new T.Mesh(new T.CylinderGeometry(.16,.17,1.45,24),shell);body.rotation.x=Math.PI/2;body.position.z=.16;root.add(body);
 const gimbal=new T.Mesh(new T.SphereGeometry(.205,24,16),shell);gimbal.scale.z=.83;gimbal.position.z=-.69;root.add(gimbal);
 for(const [x,y,r]of [[-.075,-.035,.076],[.078,.025,.058]]){const lens=new T.Mesh(new T.CircleGeometry(r,20),glass);lens.rotation.y=Math.PI;lens.position.set(x,y,-.856);root.add(lens);}
 const rim=new T.Mesh(new T.TorusGeometry(.15,.018,8,24),dark);rim.position.z=-.80;root.add(rim);
 const adapter=new T.Mesh(new T.BoxGeometry(.11,.25,.64),shell);adapter.position.set(.06,.24,.14);root.add(adapter);return root;
}
