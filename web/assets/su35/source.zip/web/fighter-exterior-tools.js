import * as T from './vendor/three.module.js';

// Shared construction tools, rather than shared aircraft silhouettes. SI units,
// closed airfoil edges, open inlet ducts and restrained painted markings.
export const lerp=(a,b,t)=>a+(b-a)*t;
export function fair(stations,n=4){
 const slope=(i,k)=>{const m=stations.length;if(i===0)return(stations[1][k]-stations[0][k])/(stations[1][0]-stations[0][0]);if(i===m-1)return(stations[i][k]-stations[i-1][k])/(stations[i][0]-stations[i-1][0]);const a=(stations[i][k]-stations[i-1][k])/(stations[i][0]-stations[i-1][0]),b=(stations[i+1][k]-stations[i][k])/(stations[i+1][0]-stations[i][0]);return a*b<=0?0:2*a*b/(a+b);};
 const out=[];for(let i=0;i<stations.length-1;i++)for(let j=0;j<n;j++){const t=j/n,t2=t*t,t3=t*t2,h=stations[i+1][0]-stations[i][0];out.push(stations[i].map((v,k)=>k? (2*t3-3*t2+1)*v+(t3-2*t2+t)*h*slope(i,k)+(-2*t3+3*t2)*stations[i+1][k]+(t3-t2)*h*slope(i+1,k):lerp(v,stations[i+1][k],t)));}out.push(stations.at(-1));return out;
}
export function geometry(p,ix){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setIndex(ix);g.computeVertexNormals();return g;}
const thickness=(u,t)=>5*t*(.2969*Math.sqrt(Math.max(0,u))-.126*u-.3516*u*u+.2843*u*u*u-.1036*u*u*u*u);
function section(rows,x){let i=rows.findIndex((a,n)=>n<rows.length-1&&x>=a[0]&&x<=rows[n+1][0]);if(i<0)i=x<rows[0][0]?0:rows.length-2;const a=rows[i],b=rows[i+1],t=(x-a[0])/(b[0]-a[0]);return a.map((v,k)=>lerp(v,b[k],t));}

export function wingPanel(k,stations,part,{c0=0,c1=1,parent,upper=true,lower=true,skipUpper}={}){
 const detailedTwin=k.d.id>=4,rows=detailedTwin?T.MathUtils.clamp(Math.ceil(Math.abs(stations.at(-1)[0]-stations[0][0])*4),4,24):24;
 const cols=detailedTwin?T.MathUtils.clamp(Math.ceil((c1-c0)*22),4,22):22,stride=cols+1,bank=(rows+1)*stride,p=[],ix=[],side=Math.sign(stations[0][0])||1;
 const source=stations.map(a=>[Math.abs(a[0]),...a.slice(1)]).sort((a,b)=>a[0]-b[0]);
 for(const skin of [1,-1])for(let j=0;j<=rows;j++){const a=section(source,lerp(source[0][0],source.at(-1)[0],j/rows));for(let i=0;i<=cols;i++){const u=lerp(c0,c1,(1-Math.cos(i/cols*Math.PI))*.5);p.push(side*a[0],a[1]+skin*thickness(u,a[4])+.025*a[4]*Math.sin(u*Math.PI),lerp(a[2],a[3],u));}}
 const face=(a,b,c,flip)=>ix.push(...(flip?[a,c,b]:[a,b,c]));
 for(let skin=0;skin<2;skin++)if(skin?lower:upper)for(let j=0;j<rows;j++)for(let i=0;i<cols;i++){
  if(!skin&&skipUpper){const x=lerp(source[0][0],source.at(-1)[0],(j+.5)/rows),u=lerp(c0,c1,(1-Math.cos((i+.5)/cols*Math.PI))*.5);if(skipUpper(x,u))continue;}
  const a=skin*bank+j*stride+i,b=a+stride,flip=(side<0)!==!!skin;face(a,a+1,b,flip);face(a+1,b+1,b,flip);
 }
 if(upper&&lower){for(let j=0;j<rows;j++)for(const i of [0,cols]){const a=j*stride+i,b=a+stride;face(a,b,a+bank,(i===0)!==(side<0));face(b,b+bank,a+bank,(i===0)!==(side<0));}for(const j of [0,rows])for(let i=0;i<cols;i++){const a=j*stride+i,b=a+1;face(a,a+bank,b,(j===0)!==(side<0));face(b,a+bank,b+bank,(j===0)!==(side<0));}}
 const m=k.mesh(geometry(p,ix),k.materials.skin,part,parent);m.name='continuous airfoil skin / '+part;return m;
}
export function verticalFin(k,rows,side,part,c0=0,c1=1,parent){
 const source=fair(rows,4),R=source.length,N=k.d.id>=4?Math.max(6,Math.ceil((c1-c0)*24)):24,stride=N+1,bank=R*stride,p=[],ix=[];
 for(const skin of [-1,1])for(const a of source)for(let j=0;j<=N;j++){const u=lerp(c0,c1,j/N);p.push(side*a[4]+skin*thickness(u,a[3]),a[0],lerp(a[1],a[2],u));}
 const f=(a,b,c,flip)=>ix.push(...(flip?[a,c,b]:[a,b,c]));
 for(let skin=0;skin<2;skin++)for(let i=0;i<R-1;i++)for(let j=0;j<N;j++){const a=skin*bank+i*stride+j,b=a+stride;f(a,b,a+1,!skin);f(a+1,b,b+1,!skin);}
 for(let i=0;i<R-1;i++)for(const j of [0,N]){const a=i*stride+j,b=a+stride;f(a,b,a+bank,j===0);f(b,b+bank,a+bank,j===0);}for(const i of [0,R-1])for(let j=0;j<N;j++){const a=i*stride+j,b=a+1;f(a,a+bank,b,i===0);f(b,a+bank,b+bank,i===0);}
 const mesh=k.mesh(geometry(p,ix),k.materials.skin,part,parent);mesh.name='full-profile fin / rudder '+part;return mesh;
}

export function inlet(k,{side,cx,cy,z,width,height,depth=2,part,ramp=true}){
 const M=k.materials,N=64,steps=14,p=[],ix=[],loop=(a,w,h)=>{const c=Math.cos(a),s=Math.sin(a);return[Math.sign(c)*Math.pow(Math.abs(c),.34)*w,Math.sign(s)*Math.pow(Math.abs(s),.34)*h];};
 // Rolled lip joins the exterior shell to a real, curved interior wall.
 for(let j=0;j<=steps;j++){const t=j/steps,inside=t>.24,f=inside?(t-.24)/.76:0;
  const w=inside?lerp(width*.88,width*.60,f):width*(1-.12*Math.sin(t/.24*Math.PI/2));
  const h=inside?lerp(height*.87,height*.61,f):height*(1-.13*Math.sin(t/.24*Math.PI/2));
  const zz=z+(inside?.12+depth*f:.12*t/.24),centre=side*cx-side*.18*f*f;
  for(let i=0;i<=N;i++){const a=i/N*Math.PI*2,[x,y]=loop(a,w,h);p.push(centre+x,cy+y+.12*f*f,zz);}
 }
 for(let j=0;j<steps;j++)for(let i=0;i<N;i++){const a=j*(N+1)+i,b=a+N+1;ix.push(a,b,a+1,a+1,b,b+1);}
 const mesh=k.mesh(geometry(p,ix),M.skinLight,part);mesh.material.side=T.DoubleSide;mesh.name='rounded inlet lip and recessed curved duct';
 k.tube(width*.61,width*.61,.08,[side*(cx-.18),cy+.12,z+depth+.12],part,M.dark);
 for(let i=0;i<16;i++){const a=i/16*Math.PI*2,r=width*.35;const g=new T.BoxGeometry(width*.31,.018,.05);g.rotateZ(a+.55);g.translate(side*(cx-.18)+Math.cos(a)*r,cy+.12+Math.sin(a)*r,z+depth+.055);k.mesh(g,M.metal,part);}
 if(ramp){
  const h=k.hinge(part,[side*cx,cy+height*.68,z+.25],'intakeRamp',[1,0,0],1);
  k.solid([[side*cx-width*.83,cy+height*.68,z+.25],[side*cx+width*.83,cy+height*.68,z+.25],[side*cx+width*.68,cy+height*.20,z+1.35],[side*cx-width*.68,cy+height*.20,z+1.35]],part,M.skinDark,.028,h);
 }
 for(const y of [-1,1])k.line([[side*cx-width*.92,cy+y*height*.93,z+.02],[side*cx+width*.92,cy+y*height*.93,z+.02]],part,M.metal,.008);
 return mesh;
}

export function seat(k,z,{x=0,y=.52,width=.48}={}){
 const M=k.materials;const g=new T.BoxGeometry(width,.80,.20);g.rotateX(.16);g.translate(x,y+.36,z+.20);k.mesh(g,M.seat,11);
 k.box([width,.12,.47],[x,y-.05,z],11,M.seat);k.box([width*.62,.27,.23],[x,y+.83,z+.22],11,M.dark);
 for(const side of [-1,1]){k.line([[x+side*width*.43,y-.02,z+.30],[x+side*width*.43,y+.65,z+.31]],11,M.metal,.016);k.line([[x+side*.15,y+.73,z+.06],[x+side*.17,y+.42,z+.02],[x+side*.19,y+.02,z-.07]],11,M.skinLight,.025);}
 const handle=[];for(let j=0;j<=18;j++){const a=j/18*Math.PI;handle.push([x+Math.cos(a)*.15,y+.93+Math.sin(a)*.10,z+.16]);}k.line(handle,11,M.yellow,.013);
}
export function cockpit(k,{front,rear,base=.5,hudOffset=-.18,consoleInset=.50,crew=false,hudRise=.94,hudBase=.58}){
 const M=k.materials;for(const side of [-1,1])k.box([.14,.18,rear-front],[side*consoleInset,base+.04,(front+rear)*.5],11,M.dark);
 const uniform=crew?new T.MeshStandardMaterial({color:0x4c5843,roughness:.94,metalness:0}):null,helmet=crew?new T.MeshStandardMaterial({color:0xa2aaa6,roughness:.68,metalness:.06}):null;
 for(const z of [front+.55,...(rear-front>3?[front+2.05]:[])]){
  seat(k,z,{y:base+(crew?.04:.10)});
  if(crew){
   k.ellipsoid([.185,.29,.13],[0,base+.29,z+.01],11,uniform,undefined,24);
   k.ellipsoid([.125,.14,.125],[0,base+.69,z-.015],11,helmet,undefined,24);
   k.ellipsoid([.112,.052,.026],[0,base+.717,z-.127],11,M.dark,undefined,20);
   k.ellipsoid([.064,.058,.050],[0,base+.64,z-.135],11,M.skinDark,undefined,16);
   for(const side of [-1,1]){
    k.line([[side*.16,base+.46,z],[side*.23,base+.25,z-.09],[side*.11,base+.15,z-.28]],11,uniform,.061);
    k.line([[side*.10,base+.50,z-.11],[side*.12,base+.24,z-.14]],11,M.skinLight,.021);
   }
   k.line([[.05,base+.63,z-.16],[.13,base+.50,z-.20],[.16,base+.30,z-.16]],11,M.dark,.017);
  }
 }
 const screens=new T.MeshStandardMaterial({color:0x172a26,roughness:.32,emissive:0x071d12,emissiveIntensity:.15});
 for(const zz of [front+.02,...(rear-front>3?[front+1.52]:[])]){k.box([.72,.34,.10],[0,base+.17,zz],11,M.frame);for(const x of [-.20,0,.20])k.box([.17,.17,.014],[x,base+.22,zz-.058],11,screens);k.ellipsoid([.48,.17,.26],[0,base+.38,zz],11,M.dark);}
 const glass=new T.MeshPhysicalMaterial({color:0x8cae9a,roughness:.06,transparent:true,opacity:.25,side:T.DoubleSide,depthWrite:false});
 k.solid([[-.19,base+hudBase,front+hudOffset],[.19,base+hudBase,front+hudOffset],[.17,base+hudRise,front+hudOffset-.10],[-.17,base+hudRise,front+hudOffset-.10]],11,glass,.003);
 for(const side of [-1,1])k.line([[side*.21,base+.48,front+hudOffset+.05],[side*.20,base+.61,front+hudOffset],[side*.17,base+hudRise+.01,front+hudOffset-.10]],11,M.frame,.010);
}

const FONT={A:['01110','10001','10001','11111','10001','10001','10001'],F:['11111','10000','10000','11110','10000','10000','10000'],N:['10001','11001','10101','10101','10011','10001','10001'],V:['10001','10001','10001','10001','01010','01010','00100'],Y:['10001','10001','01010','00100','00100','00100','00100'],R:['11110','10001','10001','11110','10100','10010','10001'],L:['10000','10000','10000','10000','10000','10000','11111'],U:['10001','10001','10001','10001','10001','10001','01110'],S:['01111','10000','10000','01110','00001','00001','11110'],'0':['01110','10001','10011','10101','11001','10001','01110'],'1':['00100','01100','00100','00100','00100','00100','01110'],'4':['10010','10010','10010','11111','00010','00010','00010'],'5':['11111','10000','10000','11110','00001','00001','11110']};
export function stencil(k,text,origin,scale,part,plane='side',side=1){
 const p=[],ix=[];for(let c=0;c<text.length;c++){const glyph=FONT[text[c]];if(!glyph)continue;for(let r=0;r<7;r++)for(let col=0;col<5;col++)if(glyph[r][col]==='1'){
  const u=(c*6+col)*scale,v=(6-r)*scale,w=scale*.88,h=scale*.88,base=p.length/3;
  for(const [a,b] of [[u,v],[u+w,v],[u+w,v+h],[u,v+h]])p.push(...(plane==='side'?[origin[0],origin[1]+b,origin[2]+(side>0?text.length*6*scale:0)-side*a]:[origin[0]+side*a,origin[1],origin[2]+b]));ix.push(base,base+1,base+2,base,base+2,base+3);
 }}
 const m=k.mesh(geometry(p,ix),k.materials.seam,part);m.material.side=T.DoubleSide;m.userData.paintedMarking=true;return m;
}
export function roundel(k,pos,size,part,plane='top',side=1){
 const M=k.materials;const points=[];for(let i=0;i<10;i++){const a=Math.PI/2+i*Math.PI/5,r=size*(i%2?.40:1),u=Math.cos(a)*r,v=Math.sin(a)*r;points.push(plane==='top'?[pos[0]+u,pos[1],pos[2]+v]:[pos[0],pos[1]+v,pos[2]+side*u]);}
 k.solid(points,part,M.seam,.0015);const bars=plane==='top'?[[pos[0]-size*1.7,pos[1],pos[2]+size*.17],[pos[0]+size*1.7,pos[1],pos[2]+size*.17]]:[[pos[0],pos[1]+size*.17,pos[2]-size*1.7],[pos[0],pos[1]+size*.17,pos[2]+size*1.7]];k.line(bars,part,M.seam,size*.10);
}
