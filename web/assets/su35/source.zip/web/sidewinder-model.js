import * as T from './vendor/three.module.js';
// Original mesh based on NAVAIR's public AIM-9X silhouette and external size.
export const SIDEWINDER_SIZE=Object.freeze({length:3.02,diameter:.13,span:.45});
export function createSidewinderModel(variant='x'){
 const root=new T.Group();root.name='AIM-9'+variant.toUpperCase()+' Sidewinder';
 const paint=new T.MeshStandardMaterial({color:0xbfc3c0,roughness:.44,metalness:.18}),metal=new T.MeshStandardMaterial({color:0x727a79,roughness:.47,metalness:.68}),optic=new T.MeshPhysicalMaterial({color:0x293633,roughness:.14,metalness:.36,clearcoat:1,clearcoatRoughness:.06}),yellow=new T.MeshStandardMaterial({color:0xb99e45,roughness:.6}),brown=new T.MeshStandardMaterial({color:0x715b42,roughness:.6});
 function cylinder(radius,length,z,material,segments=18){const g=new T.CylinderGeometry(radius,radius,length,segments);g.rotateX(Math.PI/2);const m=new T.Mesh(g,material);m.position.z=z;m.castShadow=m.receiveShadow=true;root.add(m);return m;}
 cylinder(.065,2.76,.07,paint);cylinder(.0655,.035,-.77,yellow);cylinder(.0655,.035,.40,brown);cylinder(.066,.045,-.30,metal);cylinder(.066,.055,1.40,metal);
 const dome=new T.Mesh(new T.SphereGeometry(.065,18,10,0,Math.PI*2,0,Math.PI/2),optic);dome.rotation.x=-Math.PI/2;dome.position.z=-1.445;root.add(dome);
 cylinder(.065,.13,-1.38,metal);cylinder(.045,.025,1.497,new T.MeshStandardMaterial({color:0x202725,roughness:.92,metalness:.2}));
 function fin(poly,angle){const positions=[],n=poly.length;for(const y of [-.003,.003])for(const [r,z]of poly)positions.push(r,y,z);const indices=[];for(let i=1;i<n-1;i++)indices.push(0,i+1,i,n,n+i,n+i+1);for(let i=0;i<n;i++){const j=(i+1)%n;indices.push(i,j,n+j,i,n+j,n+i);}const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setIndex(indices);g.computeVertexNormals();const m=new T.Mesh(g,paint);m.rotation.z=angle;m.castShadow=m.receiveShadow=true;root.add(m);}
 for(let i=0;i<4;i++){const a=Math.PI/4+i*Math.PI/2;fin([[.061,-1.10],[variant==='x'?.108:.20,-.86],[variant==='x'?.108:.20,-.64],[.061,-.61]],a);fin([[.061,.77],[.225,1.12],[.225,1.43],[.061,1.46]],a);}
 // Small cable cover under the body, not an external aircraft pylon.
 const cover=new T.Mesh(new T.BoxGeometry(.018,.018,1.50),paint);cover.position.set(0,-.065,.20);root.add(cover);
 root.userData.dimensions={...SIDEWINDER_SIZE};return root;
}
