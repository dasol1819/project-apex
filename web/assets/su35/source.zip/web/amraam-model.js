import * as T from './vendor/three.module.js';
import {createPhoenixModel} from './phoenix-model.js';
// Public USAF generic AIM-120 external dimensions. Clipped fins and fittings
// are an original C-style illustration, not manufacturer production CAD.
export const AMRAAM_SIZE=Object.freeze({length:3.66,diameter:.178,span:.526});
export function createAmraamModel(variant='amraam'){
 if(variant==='phoenix')return createPhoenixModel();
 const root=new T.Group();root.name='AIM-120 AMRAAM';root.userData.dimensions={...AMRAAM_SIZE};
 const paint=new T.MeshStandardMaterial({color:0xbfc3c3,roughness:.52,metalness:.22}),nose=new T.MeshStandardMaterial({color:0xc5c7bb,roughness:.65}),metal=new T.MeshStandardMaterial({color:0x68716f,roughness:.48,metalness:.65}),yellow=new T.MeshStandardMaterial({color:0xaf9343,roughness:.7}),brown=new T.MeshStandardMaterial({color:0x73553f,roughness:.7});
 function cylinder(radius,length,z,mat){const g=new T.CylinderGeometry(radius,radius,length,16);g.rotateX(Math.PI/2);const m=new T.Mesh(g,mat);m.position.z=z;m.castShadow=m.receiveShadow=true;root.add(m);return m;}
 cylinder(.089,2.98,.30,paint);const g=new T.ConeGeometry(.089,.64,16);g.rotateX(-Math.PI/2);const tip=new T.Mesh(g,nose);tip.position.z=-1.51;root.add(tip);
 cylinder(.0895,.035,-.92,yellow);cylinder(.0895,.035,.57,brown);cylinder(.09,.055,1.77,metal);cylinder(.059,.03,1.815,new T.MeshStandardMaterial({color:0x242b2b,roughness:.9}));
 function fin(poly,a){const p=[],n=poly.length,ix=[];for(const y of [-.003,.003])for(const [x,z]of poly)p.push(x,y,z);for(let i=1;i<n-1;i++)ix.push(0,i+1,i,n,n+i,n+i+1);for(let i=0;i<n;i++){const j=(i+1)%n;ix.push(i,j,n+j,i,n+j,n+i);}const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(p,3));geo.setIndex(ix);geo.computeVertexNormals();const m=new T.Mesh(geo,paint);m.rotation.z=a;m.castShadow=true;root.add(m);}
 for(let i=0;i<4;i++){const a=Math.PI/4+i*Math.PI/2;fin([[.085,-.45],[.263,-.05],[.263,.44],[.085,.61]],a);fin([[.085,1.02],[.208,1.27],[.208,1.66],[.085,1.74]],a);}
 if(variant==='sparrow'){root.name='AIM-7E-2 Sparrow';root.scale.set(1.16,1.16,1);for(let i=0;i<4;i++)fin([[.085,-.75],[.48,.15],[.48,.65],[.085,.78]],Math.PI/4+i*Math.PI/2);}
 return root;
}
