import * as THREE from './vendor/three.module.js';

// Painted from the visible relationships in USAF exterior photographs: broad
// soft grey camouflage, pale perimeter RAM, local coating repairs and aft heat
// staining. These are original analytic masks, not a photograph projected onto
// the model or a claim to reproduce a particular airframe's maintenance state.
const surfaceFunctions = `
  varying vec3 vSkinP;
  uniform float skinIntegrity;
  uniform float skinRegion;
  float skinHash(vec3 p){p=fract(p*.3183099+vec3(.1,.3,.7));p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
  float skinNoise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(mix(skinHash(i),skinHash(i+vec3(1,0,0)),f.x),mix(skinHash(i+vec3(0,1,0)),skinHash(i+vec3(1,1,0)),f.x),f.y),mix(mix(skinHash(i+vec3(0,0,1)),skinHash(i+vec3(1,0,1)),f.x),mix(skinHash(i+vec3(0,1,1)),skinHash(i+vec3(1,1,1)),f.x),f.y),f.z);}
  float skinSegment(vec2 p,vec2 a,vec2 b){vec2 d=b-a;return length(p-a-d*clamp(dot(p-a,d)/dot(d,d),0.,1.));}
  float skinLobe(vec2 p,vec2 c,vec2 r,float angle){float a=cos(angle),b=sin(angle);vec2 q=mat2(a,-b,b,a)*(p-c)/r;return 1.-smoothstep(.83,1.11,length(q));}
  float skinField(vec2 p,vec2 a,vec2 b,vec2 c,vec2 d,float blur){
    vec2 ab=b-a,bc=c-b,cd=d-c,da=a-d;
    float turn=sign(ab.x*bc.y-ab.y*bc.x);
    float edge=min(min(turn*(ab.x*(p.y-a.y)-ab.y*(p.x-a.x))/length(ab),turn*(bc.x*(p.y-b.y)-bc.y*(p.x-b.x))/length(bc)),min(turn*(cd.x*(p.y-c.y)-cd.y*(p.x-c.x))/length(cd),turn*(da.x*(p.y-d.y)-da.y*(p.x-d.x))/length(da)));
    return smoothstep(-blur,blur,edge);
  }
  float skinBox(vec2 p,vec2 b){vec2 q=abs(p)-b;return length(max(q,0.))+min(max(q.x,q.y),0.);}
  float skinToothBox(vec2 p,vec2 b,float pitch,float depth){
    vec2 q=abs(p)-b;
    q.x+=(abs(fract((p.y+b.y)/pitch)*2.-1.)-.5)*depth;
    q.y+=(abs(fract((p.x+b.x)/pitch)*2.-1.)-.5)*depth;
    return max(q.x,q.y);
  }
  // The wing outline includes the trailing controls. Its light border therefore
  // remains continuous when they are neutral; the frozen coordinates follow
  // each control's real hinge rotation when it deflects.
  float skinWingRim(vec2 p){
    float d=skinSegment(p,vec2(1.23,-2.53),vec2(2.12,-1.71));
    d=min(d,skinSegment(p,vec2(2.12,-1.71),vec2(6.78,2.59)));
    d=min(d,skinSegment(p,vec2(6.78,2.59),vec2(6.43,3.79)));
    d=min(d,skinSegment(p,vec2(6.43,3.79),vec2(2.16,5.69)));
    return d;
  }
  float skinTailRim(vec2 p){
    float d=skinSegment(p,vec2(1.30,5.03),vec2(2.77,5.67));
    d=min(d,skinSegment(p,vec2(2.77,5.67),vec2(4.42,7.05)));
    d=min(d,skinSegment(p,vec2(4.42,7.05),vec2(4.42,8.34)));
    d=min(d,skinSegment(p,vec2(4.42,8.34),vec2(2.80,8.88)));
    d=min(d,skinSegment(p,vec2(2.80,8.88),vec2(1.15,7.36)));
    return d;
  }
  // x: camouflage, y: pale edge treatment, z: service-panel tape, w: repair coat.
  vec4 skinLayout(vec3 p,float foot){
    vec2 xz=vec2(abs(p.x),p.z);float camo=0.,edge=0.,tape=0.,repair=0.;
    float blur=max(.025,foot*.65),panel=10.;
    if(skinRegion<.5){
      float a=skinField(xz,vec2(.35,-3.80),vec2(1.32,-2.15),vec2(1.62,.80),vec2(.55,1.75),.085);
      float b=skinField(xz,vec2(.35,1.10),vec2(1.68,.35),vec2(1.34,4.8),vec2(.42,5.10),.09);
      camo=max(a,b)*smoothstep(-.10,.24,p.y);
      panel=min(abs(skinToothBox(xz-vec2(.79,3.64),vec2(.41,.43),.20,.085)),abs(skinToothBox(xz-vec2(.80,.12),vec2(.31,.46),.19,.072)));
      panel=min(panel,abs(skinBox(mat2(.82,-.57,.57,.82)*(xz-vec2(1.42,-1.10)),vec2(.19,.28))));
      tape=(1.-smoothstep(.018+blur*.15,.038+blur*.7,panel))*smoothstep(.05,.32,p.y);
      repair=(1.-smoothstep(-blur,blur,skinToothBox(xz-vec2(.79,3.64),vec2(.36,.38),.20,.072)))*.57;
      repair+=(1.-smoothstep(-blur,blur,skinBox(xz-vec2(.64,-2.65),vec2(.24,.31))))*.35;
      repair*=smoothstep(.05,.3,p.y);
      edge=(1.-smoothstep(.035,.14,abs(p.x)-.84))*smoothstep(-7.5,-6.8,p.z)*(1.-smoothstep(-4.9,-4.3,p.z))*.18;
    }else if(skinRegion<1.5){
      camo=max(skinField(xz,vec2(1.70,-.55),vec2(3.75,.20),vec2(5.70,3.03),vec2(3.92,3.80),.09),skinField(xz,vec2(2.25,2.75),vec2(3.95,3.10),vec2(3.48,4.83),vec2(2.12,5.18),.085));
      edge=1.-smoothstep(.15,.24+blur,skinWingRim(xz));camo*=1.-edge;
      vec2 service=mat2(.74,-.673,.673,.74)*(xz-vec2(2.62,.25));
      float d=skinToothBox(service,vec2(.27,.39),.19,.05);
      tape=(1.-smoothstep(.010+blur*.1,.027+blur*.45,abs(d)))*.60;
      repair=(1.-smoothstep(-blur,blur,d))*.15;
    }else if(skinRegion<2.5){
      camo=skinField(xz,vec2(1.62,5.77),vec2(2.74,6.12),vec2(4.03,8.03),vec2(2.62,8.40),.075);
      edge=1.-smoothstep(.12,.21+blur,skinTailRim(xz));camo*=1.-edge;
      float d=skinBox(mat2(.85,-.53,.53,.85)*(xz-vec2(2.26,6.45)),vec2(.18,.30));
      tape=(1.-smoothstep(.009+blur*.1,.025+blur*.3,abs(d)))*.30;
    }else if(skinRegion<3.5){
      vec2 zy=p.zy;
      camo=max(skinLobe(zy,vec2(4.37,1.39),vec2(.48,.70),.19),skinLobe(zy,vec2(5.05,1.15),vec2(.69,.44),.15));
      float d=skinSegment(zy,vec2(2.58,.43),vec2(4.42,2.93));
      d=min(d,skinSegment(zy,vec2(4.42,2.93),vec2(5.94,2.95)));
      edge=1.-smoothstep(.10,.17+blur,d);camo*=1.-edge;
    }
    return vec4(camo,edge,tape,repair);
  }
  vec3 skinBump(vec3 n,vec3 p,float h){vec3 dx=dFdx(p),dy=dFdy(p);vec3 rx=cross(dy,n),ry=cross(n,dx);float det=dot(dx,rx);if(abs(det)<1.e-12)return n;return normalize(abs(det)*n-sign(det)*(dFdx(h)*rx+dFdy(h)*ry));}
`;

export function applyAirframeSurface(material, kind, part, integrity) {
  const isSkin=kind==='ram', isMetal=kind==='metal';
  const region=[0,10,11,27,28,29].includes(part)?0:[1,2,12,13,14,15,16,17,18,19].includes(part)?1:[3,4].includes(part)?2:[5,6,20,21].includes(part)?3:4;
  material.userData.airframeSurface=true;
  material.onBeforeCompile=shader=>{
    shader.uniforms.skinIntegrity=integrity;
    shader.uniforms.skinRegion={value:region};
    shader.vertexShader='attribute vec3 skinPosition;\nvarying vec3 vSkinP;\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvSkinP=skinPosition;');
    shader.fragmentShader=surfaceFunctions+shader.fragmentShader;
    shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`#include <map_fragment>
      float skinFoot=max(length(dFdx(vSkinP)),length(dFdy(vSkinP)));
      float skinFine=1.-smoothstep(.006,.032,skinFoot);
      float ramGrain=mix(.5,skinNoise(vSkinP*67.)*.57+skinNoise(vSkinP*21.)*.43,skinFine);
      float coatVariation=skinNoise(vSkinP*vec3(2.2,.85,3.6))-.5;
      vec4 skinPattern=${isSkin?'skinLayout(vSkinP,skinFoot)':'vec4(0.)'};
      float aftStain=smoothstep(3.6,6.7,vSkinP.z)*smoothstep(.30,.55,abs(vSkinP.x))*(1.-smoothstep(1.30,1.70,abs(vSkinP.x)));
      float streak=skinNoise(vSkinP*vec3(15.,3.,.56));
      float chipField=skinNoise(vSkinP*vec3(2.4,3.7,2.8));
      float scar=smoothstep(.42+.40*skinIntegrity,.62+.30*skinIntegrity,chipField)*(1.-skinIntegrity);
      ${isSkin?`vec3 coat=mix(vec3(1.015,1.015,1.01),vec3(.72,.735,.75),skinPattern.x);
      coat=mix(coat,vec3(1.10,1.10,1.085),skinPattern.y*.65);
      coat+=skinPattern.z*.055+skinPattern.w*.040+coatVariation*.008+(ramGrain-.5)*.009;
      coat*=1.-aftStain*(.025+streak*.035);
      diffuseColor.rgb*=coat;` : isMetal?`diffuseColor.rgb*=.97+ramGrain*.025+coatVariation*.025;
      diffuseColor.rgb*=mix(vec3(.94,.97,1.),vec3(1.,.985,.95),smoothstep(.25,.83,streak));
      diffuseColor.rgb*=1.-smoothstep(6.16,6.76,vSkinP.z)*(.06+streak*.09);` : 'diffuseColor.rgb*=.95+(ramGrain-.5)*.045;'}
      diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.041,.043,.043),scar*.83);
    `);
    shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>',`#include <roughnessmap_fragment>
      roughnessFactor=clamp(roughnessFactor+(ramGrain-.5)*.025+coatVariation*.04+skinPattern.x*.065+skinPattern.z*.12-skinPattern.w*.075+aftStain*.07+scar*.29,.29,.96);`);
    shader.fragmentShader=shader.fragmentShader.replace('#include <metalnessmap_fragment>',`#include <metalnessmap_fragment>
      metalnessFactor=clamp(metalnessFactor${isSkin?'-skinPattern.x*.07-skinPattern.z*.12+skinPattern.w*.05':''}-scar*.25,0.,.95);`);
    shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>',`#include <normal_fragment_maps>
      // Micrometre-scale coating grain and flush tape; no sheet-metal ripples.
      float coatHeight=(ramGrain-.5)*.00009*skinFine+skinPattern.z*.00017+scar*.009;
      normal=skinBump(normal,-vViewPosition,coatHeight);`);
  };
  material.customProgramCacheKey=()=>`f22-uniform-grey-coating-v8-${kind}`;
}

// Capture neutral, aircraft-local positions after geometry batching and before
// the first animation update. Never derive camouflage from deformed/world-space
// position: that would make paint slide on moving controls or detached wreckage.
export function bakeAirframeSurfaceCoordinates(root){
  root.updateWorldMatrix(true,true);
  const inverse=root.matrixWorld.clone().invert(),p=new THREE.Vector3();
  root.traverse(node=>{
    if(!node.isMesh||!node.material?.userData.airframeSurface)return;
    const g=node.geometry,position=g.attributes.position,rest=new Float32Array(position.count*3);
    const transform=new THREE.Matrix4().multiplyMatrices(inverse,node.matrixWorld);
    for(let i=0;i<position.count;i++)p.fromBufferAttribute(position,i).applyMatrix4(transform).toArray(rest,i*3);
    g.setAttribute('skinPosition',new THREE.BufferAttribute(rest,3));
  });
}
