import * as T from './vendor/three.module.js';
// Original AIM-54C illustration using the public approximately 4 m silhouette.
// No launcher electronics, real seeker or weapon-construction internals.
export const PHOENIX_SIZE=Object.freeze({length:4.0,diameter:.381,span:.914});
export function createPhoenixModel(){
 const root=new T.Group();root.name='AIM-54C Phoenix';root.userData.dimensions={...PHOENIX_SIZE};
 const paint=new T.MeshStandardMaterial({color:0xc0c4c4,roughness:.58,metalness:.14}),radome=new T.MeshStandardMaterial({color:0xb4b5a7,roughness:.67,metalness:.04}),metal=new T.MeshStandardMaterial({color:0x737c7b,roughness:.50,metalness:.68}),dark=new T.MeshStandardMaterial({color:0x20292c,roughness:.88}),yellow=new T.MeshStandardMaterial({color:0xb3984c,roughness:.7}),brown=new T.MeshStandardMaterial({color:0x765e49,roughness:.7});
 function cylinder(r,length,z,mat){const g=new T.CylinderGeometry(r,r,length,32);g.rotateX(Math.PI/2);g.translate(0,0,z);const m=new T.Mesh(g,mat);m.castShadow=m.receiveShadow=true;root.add(m);return m;}
 cylinder(.1905,3.29,.345,paint);
 const pos=[],ix=[],rings=[[-2,.001],[-1.94,.045],[-1.80,.102],[-1.60,.153],[-1.40,.181],[-1.30,.1905]],N=32;
 for(const[z,r]of rings)for(let j=0;j<=N;j++){const a=j/N*Math.PI*2;pos.push(Math.cos(a)*r,Math.sin(a)*r,z);}
 for(let i=0;i<rings.length-1;i++)for(let j=0;j<N;j++){const a=i*(N+1)+j,b=a+N+1;ix.push(a,a+1,b,a+1,b+1,b);}
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setIndex(ix);g.computeVertexNormals();root.add(new T.Mesh(g,radome));
 cylinder(.192,.055,-.98,yellow);cylinder(.192,.055,.82,brown);cylinder(.192,.020,-.51,metal);cylinder(.193,.045,1.94,metal);cylinder(.131,.022,1.992,dark);
 function fin(points,angle){const p=[],indices=[],n=points.length;for(const y of[-.007,.007])for(const[x,z]of points)p.push(x,y,z);for(let i=1;i<n-1;i++)indices.push(0,i+1,i,n,n+i,n+i+1);for(let i=0;i<n;i++){const j=(i+1)%n;indices.push(i,j,n+j,i,n+j,n+i);}const f=new T.BufferGeometry();f.setAttribute('position',new T.Float32BufferAttribute(p,3));f.setIndex(indices);f.computeVertexNormals();const m=new T.Mesh(f,paint);m.rotation.z=angle;m.castShadow=true;root.add(m);}
 for(let j=0;j<4;j++){const angle=Math.PI/4+j*Math.PI/2;fin([[.182,-.33],[.457,.10],[.457,1.10],[.185,1.31]],angle);fin([[.182,1.36],[.420,1.57],[.420,1.91],[.185,1.97]],angle);}
 for(const x of [-.075,.075]){const cover=new T.Mesh(new T.BoxGeometry(.024,.028,1.48),paint);cover.position.set(x,-.18,.06);root.add(cover);}
 return root;
}
