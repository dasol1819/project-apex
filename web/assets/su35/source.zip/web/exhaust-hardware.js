import * as T from './vendor/three.module.js';

// Exposed actuator cage of a featherless F100 nozzle. One morph mesh carries
// every link, so the visible hardware opens with the exhaust without adding
// dozens of draw calls or rebuilding geometry during flight.
export function exhaustActuators(k,{x,y,z,radius:R,part}){
 const position=[],opened=[],ix=[];
 const rod=(a,b,ao,bo,r)=>{
  const make=(start,end)=>{
   const d=new T.Vector3(...end).sub(new T.Vector3(...start));
   const g=new T.CylinderGeometry(r,r*.85,d.length(),6,1,false);
   g.applyQuaternion(new T.Quaternion().setFromUnitVectors(new T.Vector3(0,1,0),d.normalize()));
   g.translate((start[0]+end[0])/2,(start[1]+end[1])/2,(start[2]+end[2])/2);return g;
  };
  const a0=make(a,b),a1=make(ao,bo),base=position.length/3;
  position.push(...a0.attributes.position.array);opened.push(...a1.attributes.position.array);for(const n of a0.index.array)ix.push(base+n);a0.dispose();a1.dispose();
 };
 for(let i=0;i<15;i++){
  const angle=i/15*Math.PI*2,c=Math.cos(angle),s=Math.sin(angle),p=(r,dz)=>[x+c*R*r,y+s*R*r,z+dz];
  rod(p(1.12,-.63),p(1.10,-.11),p(1.12,-.63),p(1.17,-.11),.023);
  rod(p(1.10,-.11),p(.96,.26),p(1.17,-.11),p(1.10,.26),.016);
  rod(p(.99,-.43),p(1.10,-.11),p(.99,-.43),p(1.17,-.11),.013);
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(position,3));g.setIndex(ix);g.computeVertexNormals();g.morphAttributes.position=[new T.Float32BufferAttribute(opened,3)];
 const m=k.mesh(g,k.materials.metal,part);m.userData.keepDynamic=true;m.name='F100 exposed nozzle actuator cage';return m;
}
